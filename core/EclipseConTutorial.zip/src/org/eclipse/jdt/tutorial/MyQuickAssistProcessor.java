/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.jdt.tutorial;

import org.eclipse.core.runtime.CoreException;

import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;

import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.contentassist.IContextInformation;

import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.IBinding;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.QualifiedName;
import org.eclipse.jdt.core.dom.SimpleName;

import org.eclipse.jdt.ui.ISharedImages;
import org.eclipse.jdt.ui.JavaUI;
import org.eclipse.jdt.ui.text.java.IInvocationContext;
import org.eclipse.jdt.ui.text.java.IJavaCompletionProposal;
import org.eclipse.jdt.ui.text.java.IProblemLocation;
import org.eclipse.jdt.ui.text.java.IQuickAssistProcessor;

public class MyQuickAssistProcessor implements IQuickAssistProcessor {

	public boolean hasAssists(IInvocationContext context) throws CoreException {
		ASTNode covering= context.getCoveringNode();
		if (!(covering instanceof SimpleName) || covering.getLocationInParent() == QualifiedName.NAME_PROPERTY) {
			return false;
		}
		
		SimpleName name= (SimpleName) covering;
		if (name.isDeclaration()) {
			return false;
		}
		
		IBinding binding= name.resolveBinding();
		if (binding instanceof ITypeBinding) {
			ITypeBinding typeBinding= (ITypeBinding) binding;
			return typeBinding.isMember() || typeBinding.isTopLevel();
		}
		return false;
	}

	public IJavaCompletionProposal[] getAssists(final IInvocationContext context, IProblemLocation[] locations) throws CoreException {
		if (!hasAssists(context) || locations.length > 0)
			return null;
		
		IJavaCompletionProposal proposal= new IJavaCompletionProposal() {
			public void apply(IDocument document) {
				// todo: add implementation
			}
			
			public int getRelevance() {
				return 10;
			}

			public Point getSelection(IDocument document) {
				return null;
			}

			public String getAdditionalProposalInfo() {
				return null;
			}

			public String getDisplayString() {
				return "Fully qualify type";
			}

			public Image getImage() {
				return JavaUI.getSharedImages().getImage(ISharedImages.IMG_OBJS_PROTECTED);
			}

			public IContextInformation getContextInformation() {
				return null;
			}
				
		};
		return new IJavaCompletionProposal[] { proposal };
	}
}
