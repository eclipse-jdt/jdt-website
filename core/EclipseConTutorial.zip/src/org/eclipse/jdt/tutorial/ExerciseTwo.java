/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.jdt.tutorial;

import junit.framework.TestCase;

import org.eclipse.jdt.launching.JavaRuntime;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.ResourcesPlugin;

import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaCore;

public class ExerciseTwo extends TestCase {

	private IJavaProject fProject;
	private ICompilationUnit fUnit;
	
	protected void setUp() throws Exception {
		super.setUp();
		// create the project
		IProject project= ResourcesPlugin.getWorkspace().getRoot().getProject("Exercise_One");
		project.create(null);
		project.open(null);
		
		// set up the Java builder
		IProjectDescription description= project.getDescription();
		description.setNatureIds(new String[] { JavaCore.NATURE_ID});
		project.setDescription(description, null);			
		
		// set up the class path
		fProject= JavaCore.create(project);
		IClasspathEntry[] buildPath= {
			JavaCore.newSourceEntry(project.getFullPath().append("src")),
			JavaRuntime.getDefaultJREContainerEntry()};
		fProject.setRawClasspath(buildPath, project.getFullPath().append("bin"), null);
		
		// create the source folder
		IFolder sourceFolder= project.getFolder("src");
		sourceFolder.create(true, true, null);
		
		IPackageFragmentRoot root= fProject.getPackageFragmentRoot(sourceFolder);
		IPackageFragment pack= root.createPackageFragment("pack", true, null);
		
		String content=
			"package pack;" 		+ "\n" +
			"public class E {" 		+ "\n" +
			"	String first;" 		+ "\n" +
			"	public void ref()"	+ "\n" +
			"		first= first;"	+ "\n" +
			"	}"					+ "\n" +
			"}";
		
		fUnit= pack.createCompilationUnit("E.java", content, true, null);
	}
	
	protected void tearDown() throws Exception {
		fProject.getResource().delete(true, null);
		super.tearDown();
	}
	
	public void testSearch() throws Exception {
		// todo: implement the test case
	}
}
