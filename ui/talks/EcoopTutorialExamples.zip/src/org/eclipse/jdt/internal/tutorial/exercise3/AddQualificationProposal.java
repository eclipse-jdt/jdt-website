/*******************************************************************************
 * Copyright (c) 2006 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.jdt.internal.tutorial.exercise3;

import org.eclipse.text.edits.MalformedTreeException;
import org.eclipse.text.edits.TextEdit;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.contentassist.IContextInformation;

import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;

import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.Name;
import org.eclipse.jdt.core.dom.SimpleName;
import org.eclipse.jdt.core.dom.rewrite.ASTRewrite;

import org.eclipse.jdt.ui.ISharedImages;
import org.eclipse.jdt.ui.JavaUI;
import org.eclipse.jdt.ui.text.java.IJavaCompletionProposal;

public final class AddQualificationProposal implements IJavaCompletionProposal {
	
	private final SimpleName name;

	public AddQualificationProposal(SimpleName name) {
		this.name = name;
	}
	
	public void apply(IDocument document) {
		try {

			TextEdit edit = evaluateModification();
			edit.apply(document);

		} catch (JavaModelException e) {
			e.printStackTrace();
		} catch (MalformedTreeException e) {
			e.printStackTrace();
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
	}
	
	private TextEdit evaluateModification() throws JavaModelException {
		AST ast = name.getAST();

		ASTRewrite rewrite= ASTRewrite.create(ast);

		ITypeBinding binding = (ITypeBinding) name.resolveBinding();
		String qualfiedName= binding.getQualifiedName();
		Name newNode = ast.newName(qualfiedName);
		
		rewrite.replace(name, newNode, null);
		
		return rewrite.rewriteAST();
	}
	

	public int getRelevance() {
		return 10;
	}

	public Point getSelection(IDocument document) {
		return null;
	}

	public String getAdditionalProposalInfo() {
		ITypeBinding binding = (ITypeBinding) name.resolveBinding();
		String qualfiedName= binding.getQualifiedName();
		return "Change '" + name.getIdentifier() + "' to '" + qualfiedName + "'";
	}

	public String getDisplayString() {
		return "Fully qualify type";
	}

	public Image getImage() {
		return JavaUI.getSharedImages().getImage(ISharedImages.IMG_OBJS_PROTECTED);
	}

	public IContextInformation getContextInformation() {
		return null;
	}
}