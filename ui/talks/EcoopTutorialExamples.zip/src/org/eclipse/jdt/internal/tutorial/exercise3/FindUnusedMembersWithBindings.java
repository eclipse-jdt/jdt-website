/*******************************************************************************
 * Copyright (c) 2006 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.jdt.internal.tutorial.exercise3;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.jdt.internal.tutorial.exercise2.FindUnusedSearchResult;

import org.eclipse.jdt.core.Flags;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IField;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IMember;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.IBinding;
import org.eclipse.jdt.core.dom.IMethodBinding;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.IVariableBinding;
import org.eclipse.jdt.core.dom.Modifier;
import org.eclipse.jdt.core.search.IJavaSearchConstants;
import org.eclipse.jdt.core.search.IJavaSearchScope;
import org.eclipse.jdt.core.search.SearchEngine;
import org.eclipse.jdt.core.search.SearchMatch;
import org.eclipse.jdt.core.search.SearchParticipant;
import org.eclipse.jdt.core.search.SearchPattern;
import org.eclipse.jdt.core.search.SearchRequestor;

/*
 * Class that finds declarations which aren't referenced.
 */
public class FindUnusedMembersWithBindings  {
	
	private final FindUnusedSearchResult result;
	private final ICompilationUnit[] units;
	private int unusedMemberCount = 0;
		
	public FindUnusedMembersWithBindings(ICompilationUnit[] units, FindUnusedSearchResult resultReporter) {
		this.units = units;
		this.result= resultReporter;
	}
	
	private void doSearchCU(ICompilationUnit cu, IProgressMonitor monitor) throws CoreException {	
		IType[] allTypes= cu.getAllTypes();
		monitor.beginTask("Processing " + cu.getElementName(), allTypes.length); //$NON-NLS-1$
		try {
			ASTParser parser= ASTParser.newParser(AST.JLS3);
			parser.setProject(cu.getJavaProject());
			IBinding[] typeBindings = parser.createBindings(allTypes , monitor);
			
			for (int i= 0; i < typeBindings.length; i++) {
				if (monitor.isCanceled())
					throw new OperationCanceledException();
				ITypeBinding type= (ITypeBinding) typeBindings[i];
				monitor.subTask("Processing '" + type.getQualifiedName() + "'");  //$NON-NLS-1$//$NON-NLS-2$
				doSearchType(type, new NullProgressMonitor());
				monitor.worked(1);
			}
		} finally {
			monitor.done();
		}
	}

	private boolean methodOverrides(ITypeBinding declaringClass, IMethodBinding binding) throws JavaModelException {
		ITypeBinding superclass = declaringClass.getSuperclass();
		if (superclass != null) {
			if (hasMethod(superclass, binding)) {
				return true;
			}
			if (methodOverrides(superclass, binding)) {
				return true;
			}
		}
		ITypeBinding[] superInterfaces = declaringClass.getInterfaces();
		for (int i = 0; i < superInterfaces.length; i++) {
			if (hasMethod(superInterfaces[i], binding)) {
				return true;
			}
			if (methodOverrides(superInterfaces[i], binding)) {
				return true;
			}
		}
		return false;
	}
	
	private boolean hasMethod(ITypeBinding superclass, IMethodBinding binding) {
		IMethodBinding[] declaredMethods = superclass.getDeclaredMethods();
		for (int i = 0; i < declaredMethods.length; i++) {
			IMethodBinding curr = declaredMethods[i];
			int modifiers = curr.getModifiers();
			if (Modifier.isPrivate(modifiers) || Modifier.isStatic(modifiers)) {
				continue;
			}
			if (binding.isSubsignature(curr)) {
				return true;
			}
		}
		return false;
	}

	public void doSearchType(ITypeBinding typeBinding, IProgressMonitor monitor) throws CoreException {
		IMethodBinding[] methods= typeBinding.getDeclaredMethods();
		IVariableBinding[] fields= typeBinding.getDeclaredFields();		
		
		monitor.beginTask("Searching for references.", methods.length + fields.length + 2); //$NON-NLS-1$
		
		try {
			IType type= (IType) typeBinding.getJavaElement();
			if (type == null)
				return;
			
			if (!hasReferences(type, new SubProgressMonitor(monitor, 1))) {
				result.unusedElementFound(type);
				return;
			}
			if (monitor.isCanceled())
				throw new OperationCanceledException();
			

			
			for (int i = 0; i < methods.length; i++) {
				if (monitor.isCanceled())
					throw new OperationCanceledException();
				
				IMethodBinding methodBinding= methods[i];
				if (!Modifier.isStatic(methodBinding.getModifiers()) && methodOverrides(methodBinding.getDeclaringClass(), methodBinding))
					continue;
				
				IMethod method= (IMethod) methodBinding.getJavaElement();
				if (method == null)
					continue;
					
				if (hasReferences(method, new SubProgressMonitor(monitor, 1)))
					continue;
				
				result.unusedElementFound(method);
				unusedMemberCount++;
			}
			
			for (int i = 0; i < fields.length; i++) {
				if (monitor.isCanceled())
					throw new OperationCanceledException();
				
				IField field= (IField) fields[i].getJavaElement();
				if (field == null)
					continue;
				
				if (hasReferences(field, new SubProgressMonitor(monitor, 1)))
					continue;
				
				result.unusedElementFound(field);
				unusedMemberCount++;
			}
		} finally {
			monitor.done();
		}
	}

	public int getUnusedMethodCount() {
		return unusedMemberCount;
	}

	private boolean hasReferences(IMember member, IProgressMonitor monitor) throws CoreException {
		
		final class ReferenceFound extends Error {
			private static final long serialVersionUID= 1L;
		}
		
		IJavaSearchScope searchScope;
		if (Flags.isPrivate(member.getFlags())) {
			searchScope= SearchEngine.createJavaSearchScope(new IJavaElement[] { member.getCompilationUnit() });
		} else {
			searchScope= SearchEngine.createJavaSearchScope(new IJavaElement[] { member.getJavaProject() },  IJavaSearchScope.SOURCES);
		}
		SearchPattern pattern= SearchPattern.createPattern(member, IJavaSearchConstants.REFERENCES);
		SearchRequestor requestor= new SearchRequestor() {
			public void acceptSearchMatch(SearchMatch match) throws CoreException {
				if (match.getAccuracy() == SearchMatch.A_ACCURATE) {
					throw new ReferenceFound();
				}
			}
		};
		try {
			new SearchEngine().search(pattern, new SearchParticipant[] { SearchEngine.getDefaultSearchParticipant() }, searchScope, requestor, monitor);
		} catch (ReferenceFound e) {
			return true;
		}
		return false;
	}

	public void run(IProgressMonitor monitor) throws CoreException, OperationCanceledException {
		if (monitor == null)
			monitor = new NullProgressMonitor();
		try {
			monitor.beginTask("Searching unused members", this.units.length); //$NON-NLS-1$
			for (int i= 0; i < this.units.length; i++) {
				doSearchCU(units[i], new SubProgressMonitor(monitor, 1));
			}
		} finally {
			monitor.done();
		}
	}

}
