/*******************************************************************************
 * Copyright (c) 2006 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.jdt.internal.tutorial.exercise1;

import org.eclipse.core.runtime.CoreException;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.ResourcesPlugin;

import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaCore;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;

import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;

import org.eclipse.jdt.launching.JavaRuntime;

public class ExerciseOneAction implements IWorkbenchWindowActionDelegate {

	private IWorkbenchWindow window;

	public void dispose() {
	}

	public void init(IWorkbenchWindow window) {
		this.window = window;
	}

	public void run(IAction action) {
		try {
			// create the project
			IProject project= ResourcesPlugin.getWorkspace().getRoot().getProject("Exercise_One");
			if (project.exists()) {
				MessageDialog.openInformation(window.getShell(), "Exercise 1", "Project 'Exercise_One' alreday exists");
				return;
			}
			project.create(null);
			project.open(null);
			
			// set up the Java builder
			IProjectDescription description= project.getDescription();
			description.setNatureIds(new String[] { JavaCore.NATURE_ID});
			project.setDescription(description, null);			
			
			// set up the class path
			IJavaProject javaProject= JavaCore.create(project);
			IClasspathEntry[] buildPath= {
				JavaCore.newSourceEntry(project.getFullPath().append("src")),
				JavaRuntime.getDefaultJREContainerEntry()};
			javaProject.setRawClasspath(buildPath, project.getFullPath().append("bin"), null);
			
			// create the source folder
			IFolder sourceFolder= project.getFolder("src");
			sourceFolder.create(true, true, null);
			
			IPackageFragmentRoot root= javaProject.getPackageFragmentRoot(sourceFolder);
			IPackageFragment pack= root.createPackageFragment("pack", true, null);
			
			String content=
				"package pack;" 		+ "\n" +
				"public class E {" 		+ "\n" +
				"	String first;" 		+ "\n" + 
				"}";
			
			ICompilationUnit cu= pack.createCompilationUnit("E.java", content, true, null);
			
			IType type= cu.getType("E");
			type.createField("String second;", null, true, null);			
			
		} catch (CoreException e) {
			e.printStackTrace();
		}
	}

	public void selectionChanged(IAction action, ISelection selection) {
	}
}
