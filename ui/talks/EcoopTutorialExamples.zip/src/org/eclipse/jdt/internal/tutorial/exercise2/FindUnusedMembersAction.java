/*******************************************************************************
 * Copyright (c) 2006 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.jdt.internal.tutorial.exercise2;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;

import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;

import org.eclipse.search.ui.NewSearchUI;

import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.IParent;
import org.eclipse.jdt.core.JavaModelException;

public class FindUnusedMembersAction implements IObjectActionDelegate {

	private IStructuredSelection selection;
	private IWorkbenchPart part;

	public void setActivePart(IAction action, IWorkbenchPart part) {
		this.part = part;
	}

	public void run(IAction action) {
		ArrayList<ICompilationUnit> allCus= new ArrayList<ICompilationUnit>();
		try {
			for (Iterator it = selection.iterator(); it.hasNext();) {
				Object element = it.next();
				if (element instanceof IJavaElement)
					collectCompilationUnits((IJavaElement)element, allCus);
			}
		} catch (JavaModelException e) {
			ErrorDialog.openError(part.getSite().getShell(), "Find Unused Members", "Problem collecting compilation units", e.getStatus());  //$NON-NLS-1$//$NON-NLS-2$
			return;
		}
		
		if (allCus.isEmpty()) {
			MessageDialog.openInformation(part.getSite().getShell(), "Find Unused Members", "No compilation units in 'internal' packages selected"); //$NON-NLS-1$ //$NON-NLS-2$
			return;
		}
		
		ICompilationUnit[] cus= (ICompilationUnit[]) allCus.toArray(new ICompilationUnit[allCus.size()]);
		NewSearchUI.runQueryInBackground(new FindUnusedSearchQuery(cus));
	}

	private void collectCompilationUnits(IJavaElement current, Collection<ICompilationUnit> res) throws JavaModelException {
		if (current instanceof IJavaProject || current instanceof IPackageFragmentRoot) {
			IJavaElement[] children = ((IParent) current).getChildren();
			for (int i = 0; i < children.length; i++) {
				collectCompilationUnits(children[i], res);
			}
		} else if (current instanceof IPackageFragment) {
			//don't search API packages, only packages with 'internal' in name
			if (current.getElementName().indexOf("internal") > 0) { //$NON-NLS-1$
				IJavaElement[] children = ((IParent) current).getChildren();
				for (int i = 0; i < children.length; i++) {
					collectCompilationUnits(children[i], res);
				}
			}
		} else if (current instanceof ICompilationUnit)
			res.add((ICompilationUnit) current);
	}

	public void selectionChanged(IAction action, ISelection aSelection) {
		if (aSelection instanceof IStructuredSelection)
			this.selection = (IStructuredSelection) aSelection;
	}
}