/*******************************************************************************
 * Copyright (c) 2006 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.jdt.internal.tutorial.exercise2;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.core.runtime.SubProgressMonitor;

import org.eclipse.jdt.core.Flags;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IField;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IMember;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.ITypeHierarchy;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.search.IJavaSearchConstants;
import org.eclipse.jdt.core.search.IJavaSearchScope;
import org.eclipse.jdt.core.search.SearchEngine;
import org.eclipse.jdt.core.search.SearchMatch;
import org.eclipse.jdt.core.search.SearchParticipant;
import org.eclipse.jdt.core.search.SearchPattern;
import org.eclipse.jdt.core.search.SearchRequestor;

/*
 * Class that finds declarations which aren't referenced.
 */
public class FindUnusedMembers  {
	
	private final FindUnusedSearchResult result;
	private final ICompilationUnit[] units;
	private int unusedMemberCount = 0;
		
	public FindUnusedMembers(ICompilationUnit[] units, FindUnusedSearchResult resultReporter) {
		this.units = units;
		this.result= resultReporter;
	}
	
	private void doSearchCU(ICompilationUnit cu, IProgressMonitor monitor) throws CoreException {	
		IType[] allTypes= cu.getAllTypes();
		monitor.beginTask("Processing " + cu.getElementName(), allTypes.length); //$NON-NLS-1$
		try {		
			for (int i= 0; i < allTypes.length; i++) {
				if (monitor.isCanceled())
					throw new OperationCanceledException();
				IType type= allTypes[i];
				monitor.subTask("Processing '" + type.getFullyQualifiedName() + "'");  //$NON-NLS-1$//$NON-NLS-2$
				doSearchType(type, new NullProgressMonitor());
				monitor.worked(1);
			}
		} finally {
			monitor.done();
		}
	}

	private boolean methodOverrides(ITypeHierarchy typeHierarchy, IMethod method) throws JavaModelException {
		IType[] superTypes = typeHierarchy.getAllSupertypes(method.getDeclaringType());
		for (int i = 0; i < superTypes.length; i++) {
			IType superType = superTypes[i];
			IMethod[] methods = superType.findMethods(method);
			if (methods != null) {
				for (int j = 0; j < methods.length; j++) {
					int flags = methods[j].getFlags();
					if (!Flags.isPrivate(flags) && !Flags.isStatic(flags)) {
						return true;
					}
				}
			}
		}
		return false;
	}
	
	public void doSearchType(IType type, IProgressMonitor monitor) throws CoreException {
		IMethod[] methods = type.getMethods();
		IField[] fields = type.getFields();
		monitor.beginTask("Searching for references.", methods.length + fields.length + 2); //$NON-NLS-1$
		
		try {
			if (!hasReferences(type, new SubProgressMonitor(monitor, 1))) {
				result.unusedElementFound(type);
				return;
			}
			if (monitor.isCanceled())
				throw new OperationCanceledException();
			
			ITypeHierarchy typeHierarchy = type.newSupertypeHierarchy(new SubProgressMonitor(monitor, 1));
			
			for (int i = 0; i < methods.length; i++) {
				if (monitor.isCanceled())
					throw new OperationCanceledException();
				
				IMethod method= methods[i];
				if (!Flags.isStatic(method.getFlags()) && methodOverrides(typeHierarchy, method))
					continue;
					
				if (hasReferences(method, new SubProgressMonitor(monitor, 1)))
					continue;
				
				result.unusedElementFound(method);
				unusedMemberCount++;
			}
			
			for (int i = 0; i < fields.length; i++) {
				if (monitor.isCanceled())
					throw new OperationCanceledException();
				
				IField field= fields[i];
				if (hasReferences(field, new SubProgressMonitor(monitor, 1)))
					continue;
				
				result.unusedElementFound(field);
				unusedMemberCount++;
			}
		} finally {
			monitor.done();
		}
	}

	public int getUnusedMethodCount() {
		return unusedMemberCount;
	}

	private boolean hasReferences(IMember member, IProgressMonitor monitor) throws CoreException {
		
		final class ReferenceFound extends Error {
			private static final long serialVersionUID= 1L;
		}
		
		IJavaSearchScope searchScope;
		if (Flags.isPrivate(member.getFlags())) {
			searchScope= SearchEngine.createJavaSearchScope(new IJavaElement[] { member.getCompilationUnit() });
		} else {
			searchScope= SearchEngine.createJavaSearchScope(new IJavaElement[] { member.getJavaProject() },  IJavaSearchScope.SOURCES);
		}
		SearchPattern pattern= SearchPattern.createPattern(member, IJavaSearchConstants.REFERENCES);
		SearchRequestor requestor= new SearchRequestor() {
			public void acceptSearchMatch(SearchMatch match) throws CoreException {
				if (match.getAccuracy() == SearchMatch.A_ACCURATE) {
					throw new ReferenceFound();
				}
			}
		};
		try {
			new SearchEngine().search(pattern, new SearchParticipant[] { SearchEngine.getDefaultSearchParticipant() }, searchScope, requestor, monitor);
		} catch (ReferenceFound e) {
			return true;
		}
		return false;
	}

	public void run(IProgressMonitor monitor) throws CoreException, OperationCanceledException {
		if (monitor == null)
			monitor = new NullProgressMonitor();
		try {
			monitor.beginTask("Searching unused members", this.units.length); //$NON-NLS-1$
			for (int i= 0; i < this.units.length; i++) {
				doSearchCU(units[i], new SubProgressMonitor(monitor, 1));
			}
		} finally {
			monitor.done();
		}
	}

}
